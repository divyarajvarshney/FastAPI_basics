from sqlalchemy import Column, Integer, String
from database import Base

class MLA(Base):
    __tablename__ = "mlas"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    city = Column(String, index=True)
    party = Column(String)
    phone = Column(String)
