from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from database import engine, Base, get_db
from models import MLA
from pydantic import BaseModel
from pathlib import Path

# Initialize app and database
app = FastAPI()
Base.metadata.create_all(bind=engine)

# Mount static files (CSS, images, etc.)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Serve the frontend HTML
@app.get("/", response_class=HTMLResponse)
def home():
    html_path = Path("templates/index.html")
    return html_path.read_text()

# Pydantic schema for MLA
class MLASchema(BaseModel):
    name: str
    city: str
    party: str
    phone: str

    class Config:
        orm_mode = True

# API endpoints
@app.get("/mlas")
def get_mlas(db: Session = Depends(get_db)):
    mlas = db.query(MLA).all()
    return mlas

@app.get("/mlas/{city}")
def get_mlas_by_city(city: str, db: Session = Depends(get_db)):
    mlas = db.query(MLA).filter(MLA.city == city).all()
    if not mlas:
        raise HTTPException(status_code=404, detail="No MLAs found in this city")
    return mlas

@app.post("/mlas")
def add_mla(mla: MLASchema, db: Session = Depends(get_db)):
    existing_mla = db.query(MLA).filter(MLA.name == mla.name, MLA.city == mla.city).first()
    if existing_mla:
        raise HTTPException(status_code=400, detail="MLA already exists in the specified city")
    new_mla = MLA(name=mla.name, city=mla.city, party=mla.party, phone=mla.phone)
    db.add(new_mla)
    db.commit()
    db.refresh(new_mla)
    return {"message": "MLA added successfully", "mla": new_mla}
